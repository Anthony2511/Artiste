# Generic

**Style de remise à zéro (reset, normalize…)**  
