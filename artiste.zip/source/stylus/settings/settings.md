# Settings

**Variables globales**  
C'est ici que l'on mets les styles globaux, comme ceux relatif aux fonts, aux couleurs, etc.

fonts.styl
colors.styl