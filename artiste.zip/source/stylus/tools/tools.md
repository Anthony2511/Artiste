# Tools

**Mixins globaux, functions & outils**  
C'est ici que l'on mets les mixins, les fonctions, etc.