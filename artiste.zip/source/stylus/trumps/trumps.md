# Trumps

**Styles spécifique à un élément**  
C'est la couche la plus haute, qui surpasse toutes les autres.
Elle est inélégante et lourde. Elle contient de services auxiliaires, des hacks, et même des !important.